:root{--primary:{{ settings.primary_color }};--accent:{{ settings.accent_color }};--bg:{{ settings.background_color }};--text:{{ settings.text_color }}}
*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,sans-serif;background:var(--bg);color:var(--text)}
a{color:inherit;text-decoration:none}img{max-width:100%;display:block}
.container{max-width:1200px;margin:0 auto;padding:0 16px}.section{padding:40px 16px}.narrow{max-width:760px}.center{text-align:center}
.announcement{background:var(--primary);color:#fff;text-align:center;padding:8px;font-size:13px}
.header{border-bottom:1px solid #eee;position:sticky;top:0;background:var(--bg);z-index:10}
.header-inner{display:flex;align-items:center;gap:20px;height:64px}
.logo{font-weight:800;font-size:22px;letter-spacing:-.5px}.logo img{max-height:44px}
.nav{display:flex;gap:18px;flex:1}.nav a:hover{color:var(--accent)}
.search input{padding:8px 12px;border:1px solid #ddd;border-radius:999px}
.menu-toggle{display:none;background:none;border:0;font-size:22px}
.hero{background:var(--primary) center/cover;color:#fff;padding:120px 0;text-align:center}
.hero h1{font-size:clamp(32px,6vw,64px);margin:0 0 12px;font-weight:800}
.btn{display:inline-block;background:var(--primary);color:#fff;padding:12px 28px;border:0;border-radius:4px;font-weight:600;cursor:pointer}
.hero .btn{background:var(--accent)}.btn.accent{background:var(--accent)}.btn[disabled]{opacity:.5}
.grid{display:grid;gap:20px}.cols-2{grid-template-columns:repeat(2,1fr)}.cols-3{grid-template-columns:repeat(3,1fr)}.cols-4{grid-template-columns:repeat(4,1fr)}
.product-img{position:relative;aspect-ratio:3/4;background:#f3f3f3;overflow:hidden}.product-img img{width:100%;height:100%;object-fit:cover}
.badge{position:absolute;top:8px;left:8px;background:var(--accent);color:#fff;font-size:11px;padding:3px 8px;font-weight:700}
.product-card h3{font-size:15px;margin:10px 0 4px;font-weight:600}.price s{color:#999;margin-right:6px}
.product-page{display:grid;grid-template-columns:1.2fr 1fr;gap:40px}.product-gallery{display:grid;gap:12px}
.product-info form{display:grid;gap:12px;margin:20px 0}.product-info select,.product-info input[type=number]{padding:10px;border:1px solid #ddd}
.price.big{font-size:26px}
.cart-row{display:grid;grid-template-columns:80px 1fr 80px 100px;gap:16px;align-items:center;padding:12px 0;border-bottom:1px solid #eee}
.cart-total{text-align:right;font-size:20px}
.footer{background:var(--primary);color:#ddd;margin-top:60px;padding-top:40px}
.footer-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:30px}.footer a{display:block;margin:6px 0}
.copyright{padding:24px 16px;font-size:13px;opacity:.7}
@media(max-width:800px){.cols-3,.cols-4{grid-template-columns:repeat(2,1fr)}.product-page,.footer-grid{grid-template-columns:1fr}
.menu-toggle{display:block}.nav{display:none;position:absolute;top:64px;left:0;right:0;background:var(--bg);flex-direction:column;padding:16px}.nav.open{display:flex}.search{display:none}}

/* header estilo "centro" com menu em dropdown */
.header-inner{display:grid;grid-template-columns:1fr auto 1fr;gap:16px}
.header-start,.header-end{display:flex;gap:12px;align-items:center}.header-end{justify-content:flex-end}
.icon-btn{background:none;border:0;font-size:18px;cursor:pointer;position:relative}
.cart-count{position:absolute;top:-6px;right:-8px;background:var(--accent);color:#fff;border-radius:99px;font-size:10px;padding:1px 5px}
.nav{grid-column:1/-1;order:3;justify-content:center}.nav ul{list-style:none;margin:0;padding:0;display:flex;gap:22px;flex-wrap:wrap;justify-content:center}
.nav li{position:relative}.nav a{font-weight:500;font-size:14px;display:block;padding:8px 0}
.nav .sub{display:none;position:absolute;top:100%;left:0;min-width:200px;background:var(--bg);border:1px solid #eee;border-radius:12px;padding:10px 16px;flex-direction:column;gap:2px;z-index:20}
.nav .sub .sub{top:0;left:100%}.nav li:hover>.sub{display:flex}
.header-inner{height:auto;padding-top:12px;padding-bottom:4px}
.search-panel{border-top:1px solid #eee;padding:12px 0}.search-panel input{width:100%;padding:12px;border:1px solid #ddd;border-radius:999px}
/* coleção */
.banner-collection{padding:28px 0 0}.banner-collection h1{margin:8px 0 0;font-size:32px}.breadcrumb{font-size:13px;color:#777}
.toolbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;font-size:14px}
.toolbar select{padding:8px 12px;border:1px solid #ddd;border-radius:999px;margin-left:6px}
.product-card{border-radius:16px}
.product-media{position:relative;display:block;aspect-ratio:1/1;background:#f3f3f3;border-radius:16px;overflow:hidden}
.product-media img{width:100%;height:100%;object-fit:cover}
.product-media .hover-img{position:absolute;inset:0;opacity:0;transition:opacity .25s}.product-media:hover .hover-img{opacity:1}
.product-body{text-align:center;padding-top:10px}.product-body h3{font-size:15px;font-weight:600;margin:0 0 6px}
.installments,.variants{display:block;color:#666;margin-top:3px;font-size:12px}
.footer{background:#1f1f1f}.footer-col summary{font-weight:600;color:#fff;cursor:pointer;margin-bottom:10px}
.copyright{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}
.social{list-style:none;display:flex;gap:14px;padding:0}
@media(max-width:800px){.nav{display:none}.nav.open{display:block;position:static}.nav ul{flex-direction:column;align-items:flex-start}
.nav .sub{position:static;display:flex;border:0;padding:0 0 0 12px}.header-inner{grid-template-columns:1fr auto 1fr}}
